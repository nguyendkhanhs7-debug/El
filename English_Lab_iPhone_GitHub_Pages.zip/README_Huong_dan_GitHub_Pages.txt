ENGLISH LAB — HƯỚNG DẪN ĐƯA LÊN GITHUB PAGES

1. Tải và giải nén gói ZIP.
2. Đăng nhập https://github.com hoặc tạo tài khoản miễn phí.
3. Nhấn New repository.
4. Đặt tên repository: english-lab-quiz
5. Chọn Public, sau đó nhấn Create repository.
6. Trong repository, chọn Add file > Upload files.
7. Tải file index.html trong thư mục đã giải nén lên (nếu file đang tên English_Lab_Quiz_iPhone.html,
   hãy đổi tên thành index.html trước khi upload).
8. Nhấn Commit changes.
9. Mở Settings > Pages.
10. Ở mục Build and deployment, chọn Deploy from a branch.
11. Chọn branch main và folder /(root), rồi nhấn Save.
12. Đợi khoảng 1–3 phút. GitHub sẽ hiện địa chỉ trang web dạng:
    https://TEN-TAI-KHOAN.github.io/english-lab-quiz/

MỞ TRÊN IPHONE
- Mở đường link GitHub Pages bằng Safari.
- Nhấn nút Chia sẻ > Thêm vào MH chính để tạo biểu tượng mở như ứng dụng.

LƯU Ý
- Bản HTML này giữ nguyên 80 câu hỏi, đáp án, giải thích và logic chấm điểm.
- File đã bổ sung metadata và tinh chỉnh thao tác trên màn hình cảm ứng/iPhone.
- Dữ liệu câu sai được lưu trong bộ nhớ trình duyệt của thiết bị. Khi đổi trình duyệt hoặc xóa dữ liệu Safari,
  danh sách câu sai có thể không còn.
- Mở file trực tiếp trong ứng dụng Tệp có thể chỉ hiện bản xem trước và không chạy JavaScript.
  Hãy dùng link HTTPS của GitHub Pages để làm bài.
